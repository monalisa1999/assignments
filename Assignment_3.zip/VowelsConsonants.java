

import java.util.Scanner;

public class VowelsConsonants {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		String s=sc.next();
		char [] string=s.toCharArray();
		int vcount=0;
		int ccount=0;
		for(int i=0;i<string.length;i++) {
			
				if(string[i]=='a'||string[i]=='e'||string[i]=='i'||string[i]=='o'||string[i]=='u' ){
					vcount++;
			}
				else if(string[i]>'a'&& string[i]<'z'){
					ccount++;
				}
					
		}
		
		System.out.println("Number of vowels "+vcount);
		System.out.println("Number of consonants "+ccount);

	}

}
