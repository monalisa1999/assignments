public class Question_1{
	public static void main(String arg[]){
		int i,j;
		 int n=11;
		 for(i=0;i<n;i++){

			//PRINTING "I"
			for(j=0;j<n;j++){
				if(i==0 || i==n-1 || j==(n-1)/2)
					System.out.print("*");
			else 
					System.out.print(" ");
				
	 	 	}
		 	System.out.print(" ");
		//PRINTING "N"
		 	for(j=0;j<n;j++){
	 		if(j==0 || j==n-1 || i==j)
		 			System.out.print("*");
		 		else 
		 			System.out.print(" ");
				
		 	}
		 	System.out.print(" ");
		 	//PRINTING "E"
		 	for(j=0;j<n;j++){
		 		if(j==0 || i==n-1 || i==0 || i==(n-1)/2)
		 			System.out.print("*");
		 		else 
		 			System.out.print(" ");
				
		 	}
		 	System.out.print(" ");
		 	//PRINTING "U"
		 	for(j=0;j<n;j++){
		 		if(j==0 && i!=n-1 || j==n-1 && i!=n-1|| i==n-1 && j!=0 && j!=n-1)
		 			System.out.print("*");
		 		else 
		 			System.out.print(" ");
				
		 	}
		 	System.out.print(" ");
		 	//PRINTING "R"
		 	for(j=0;j<n;j++){
		 		//if(j==0 || i==0 && j!=n-1 || i==(n-1)/2 && j!=n-1)
		 		if(i==(n-1)/2 && j!=n-1 || i==0 && j!=n-1 || j==0   || j==n-1 && i!=0 && i!=(n-1)/2 )
		 			System.out.print("*");
		 		else 
		 			System.out.print(" ");
				
		 	}
		 	System.out.print(" ");
		 	//PRINTING "O"
		 	for(j=0;j<n;j++){
		 		//if(j==0 || i==0 && j!=n-1 || i==(n-1)/2 && j!=n-1)
		 		if(i==0 && j!=0 && j!=n-1 || j==0 && i!=0 && i!=n-1 || i==n-1 && j!=0 && j!=n-1 || j==n-1 && i!=0 && i!=n-1)
		 			System.out.print("*");
		 		else 
		 			System.out.print(" ");
				
		 	} 
		 	System.out.print(" ");
		 	//PRINTING "N"
		 	for(j=0;j<n;j++){
		 		if(j==0 || j==n-1 || i==j)
		 			System.out.print("*");
		 		else 
		 			System.out.print(" ");
				
		 	}



		 	System.out.println();
		 }
	}
}