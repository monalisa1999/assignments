import java.util.Scanner;

public class Pangram {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Eneter the first string");
		String str1=sc.next();
		str1=str1.toLowerCase();
		boolean [] alphabets= new boolean[26];
		int index=0;
		int flag=1;
		for(int i=0;i<str1.length();i++) {
			if(str1.charAt(i)>'a'&& str1.charAt(i)<'z') {
				index=str1.charAt(i);
			}
			alphabets[index]=true;
		}
		for(int i=0;i<=25;i++) {
			if(alphabets[i]==false)
				flag=0;
		}
		System.out.println("String: "+ str1);
		if(flag==1)
			System.out.println("Pangram");
		else
			System.out.println("Not Pangram");
		
	
		
	}

}
