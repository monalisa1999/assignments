import java.util.Scanner;
import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first string");
		String s=sc.next();
		System.out.println("Enter the second string");
		String s1=sc.next();
		s=s.toLowerCase();
		s1=s1.toLowerCase();
		if(s.length()==s1.length()) {
			char [] string=s.toCharArray();
			char [] string1=s1.toCharArray();
			Arrays.parallelSort(string);
			Arrays.parallelSort(string1);
			if(Arrays.equals(string, string1)) {
				System.out.println("The string " + s +" and " +s1 +" are anagram!");
			}
			else
				
				System.out.println("The string " + s +" and " +s1 +" are not anagram.");
		
		}
		else
			System.out.println("The string " + s +" and " +s1 +" are not anagram.");
		
		
	}

}
