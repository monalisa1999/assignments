import java.util.Scanner;

public class sortingAlphabetically {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		String s=sc.nextLine();
		char [] ar=s.toCharArray();
		char temp;
		for(int i=0;i<ar.length;i++) {
			for(int j=i+1;j<ar.length;j++) {
				if(ar[j]<ar[i]) {
					temp=ar[i];
					ar[i]=ar[j];
					ar[j]=temp;
				}
				
			}
			
		}
		
		System.out.println(ar);

	}

}
